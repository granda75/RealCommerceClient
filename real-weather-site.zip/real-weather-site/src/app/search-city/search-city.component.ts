import { Component, OnInit } from '@angular/core';
import { City } from '../model/city';
import { WeatherService } from '../service/weather.service';
import { CurrentWeather } from '../model/current-weather';
import { FavoriteCity } from '../model/favorite-city';
import { WeatherResponse } from '../model/response';



@Component({
  selector: 'app-search-city',
  templateUrl: './search-city.component.html',
  styleUrls: ['./search-city.component.css']
})
export class SearchCityComponent implements OnInit {

  title = 'Weather site !';
  public cityName: string;

  public cities         : City[];
  public city           :City = new City();
  public favoriteCity   :FavoriteCity = new FavoriteCity();
  public isCityNameFull :boolean = true;
  public isCitySelected :boolean = false;
  public currentWeather :CurrentWeather = null;
  public serverAnswer   :WeatherResponse = null;
  

  constructor(private weatherService: WeatherService) { }

  ngOnInit(): void {
  }

  //To search cities by city name
  citySearch():void
  {
       
    if (typeof this.cityName != 'undefined' && this.cityName)
    {
      this.weatherService.searchCityNames(this.cityName).subscribe(data=>{
          this.cities = data;
      });

      this.isCityNameFull = true;
    }
    else
    {
      this.isCityNameFull = false;
    }
    
  }

  //To add city to favorites city
  addFavoriteCity()
  {
      this.favoriteCity.Key = this.currentWeather.CityKey;
      this.favoriteCity.LocalizedName = this.currentWeather.CityName;
    
      try
      {
        this.weatherService.AddToFavorites(this.favoriteCity).subscribe(data=>
        {
           this.serverAnswer = data as WeatherResponse;
           if ( this.serverAnswer!= null )
           {
              alert(this.serverAnswer.Message);     
              console.log(this.serverAnswer.Message);
          }
        });
        
      }
      catch(exception)
      {
          alert("Add to favorites operation was failed");     
          console.log("Add to favorites operation was failed");
      }
  }

  

  onCitySelected(currrentWeather: CurrentWeather)
  {
      this.isCitySelected = true;
      this.currentWeather = currrentWeather;
  }

}
