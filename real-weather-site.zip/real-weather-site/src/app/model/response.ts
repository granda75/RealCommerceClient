export class WeatherResponse
{
    ErrorCode : number;
    Message : string;
}