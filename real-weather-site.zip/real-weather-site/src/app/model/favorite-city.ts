export class FavoriteCity
{
    Id: number;
    Key : string;
    LocalizedName : string;
}