// "Key": "215854",
//     "Type": "City",
//     "Rank": 31,
//     "LocalizedName": "Tel Aviv",
export class City
{
   Id       : number;
   CityName : string; 
   Key : string;
   LocalizedName : string; 
}