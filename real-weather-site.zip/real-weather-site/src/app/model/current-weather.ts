export class CurrentWeather
{
    WeatherText : string;
    Temperature : number;
    HasPrecipitation : boolean;
    CityKey : string;
    CityName: string;
    CityId: number;
}