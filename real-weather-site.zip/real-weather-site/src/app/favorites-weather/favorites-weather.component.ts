import { Component, OnInit } from '@angular/core';
import { WeatherService } from '../service/weather.service';
import { FavoriteCity } from '../model/favorite-city';
import { CurrentWeather } from '../model/current-weather';

@Component({
  selector: 'app-favorite-city-weather',
  templateUrl: './favorites-weather.component.html',
  styleUrls: ['./favorites-weather.component.css']
})
export class FavoritesWeatherComponent implements OnInit {

  public cities         : FavoriteCity[];
  public isCitySelected :boolean = false;
  public currentWeather :CurrentWeather = null;
  public favoriteCity : FavoriteCity = new FavoriteCity();

  constructor(private weatherService: WeatherService) { }

  //To get and show favorites list OnInit lifecycle hook
  ngOnInit(): void {
    this.getAllFavorites();
  }

  getAllFavorites():void
  {
      this.weatherService.GetAllFavorites().subscribe(data=>{
          this.cities = data;
      });
  }

  // Remove the selected city from favorites cities
  removeFavoriteCity() :void
  {
    this.favoriteCity.Id = this.currentWeather.CityId;
    this.favoriteCity.Key = this.currentWeather.CityKey;

    try
    {
       this.weatherService.RemoveFromFavorites(this.favoriteCity).subscribe(data => {
        this.getAllFavorites();
        this.isCitySelected = false;
        alert("City was removed from favorites");     
        console.log("City was removed from favorites");
      });
      
    }
    catch(exception)
    {
        alert("Remove from favorites operation was failed");     
        console.log("Remove from favorites operation was failed");
    }
  }

  onCitySelected(currrentWeather: CurrentWeather)
  {
      this.isCitySelected = true;
      this.currentWeather = currrentWeather;
  }

}
