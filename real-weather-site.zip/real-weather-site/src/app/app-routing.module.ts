import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { SearchCityComponent } from './search-city/search-city.component';
import { CitiesListComponent } from './cities-list/cities-list.component';
import { FavoritesWeatherComponent } from './favorites-weather/favorites-weather.component';

const routes: Routes = [
  { path:'search', component: SearchCityComponent},
  { path:'favorites', component: FavoritesWeatherComponent },
  { path:'about', component: AboutComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
