import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { City } from '../model/city';
import { Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { CurrentWeather } from '../model/current-weather';
import { FavoriteCity } from '../model/favorite-city';


@Injectable({
  providedIn: 'root'
})
export class WeatherService {

  httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
                };

  constructor(private http: HttpClient) { }

  //To search cities by name
  searchCityNames(cityName: string):Observable<City[]>
  {
    let url = environment.apiEndpoint + `/Weather/Search?cityName=` + cityName;
    return this.http.get<City[]>(url);
  }

  // To get current weather in the city
  GetCurrentWeather(cityKey: string):Observable<CurrentWeather[]>
  {
      let url = environment.apiEndpoint + `/Weather/GetCurrentWeather?cityKey=` + cityKey;
      return this.http.get<CurrentWeather[]>(url);
  }

  //To add city to favorites
  AddToFavorites(city: FavoriteCity)
  {
      let url = environment.apiEndpoint + "/Weather/AddToFavorites";
      return this.http.post(url, city, this.httpOptions).
              pipe(tap((city) => console.log(`AddToFavorites method worked`)), 
              catchError(this.handleError));
  }

  //To remove city from favorites
  RemoveFromFavorites(city: FavoriteCity)
  {
      let url = environment.apiEndpoint + "/Weather/DeleteFavorite?cityId=" + city.Id;
      return this.http.delete<string>(url, this.httpOptions).
              pipe(tap((city) => console.log(`RemoveFromFavorites method worked`)), 
              catchError(this.handleError));
  }

  //The method hadles the error from the service
  handleError(error: HttpErrorResponse) {
    let errorMessage = 'Unknown error!';
    
    if (error.error instanceof ErrorEvent) 
    {
      // Client-side errors
      errorMessage = `Error: ${error.error.message}`;
    } 
    else 
    {
      // Server-side errors
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message} `;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }

  // Get all favorites
  GetAllFavorites():Observable<FavoriteCity[]>
  {
      let url = environment.apiEndpoint + '/Weather/GetFavorites';
      return this.http.get<FavoriteCity[]>(url);
  }
  
}
