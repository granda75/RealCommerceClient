import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { City } from '../model/city';
import { WeatherService } from '../service/weather.service';
import { CurrentWeather } from '../model/current-weather';

@Component({
  selector: 'app-cities-list',
  templateUrl: './cities-list.component.html',
  styleUrls: ['./cities-list.component.css']
})
export class CitiesListComponent implements OnInit {

  @Input() cities: City[] = null;
  @Output() citySelected = new EventEmitter<CurrentWeather>();

  public currentWeatherArray: CurrentWeather[];
  public currentWeather: CurrentWeather;

  constructor(private weatherService: WeatherService) { }

  ngOnInit(): void {
  }

  //On city link click to throw event to parents component :
  //to SearchCityComponent or FavoritesWeatherComponent 
  citySelectedClick(city:City) : void
  {
    
    if (typeof city.Key != 'undefined' && city.Key)
    {
      this.weatherService.GetCurrentWeather(city.Key).subscribe(data=>{
          this.currentWeatherArray = data;
          this.currentWeather = this.currentWeatherArray[0];
          this.currentWeather.CityName = city.LocalizedName;
          this.currentWeather.CityId = city.Id;
          this.citySelected.emit(this.currentWeather);
      });
     
    }
        
  }

}
