import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchCityComponent } from './search-city/search-city.component';
import { CitiesListComponent } from './cities-list/cities-list.component';
import { AboutComponent } from './about/about.component';
import { HttpClientModule } from '@angular/common/http';
import { WeatherService } from './service/weather.service';
import { FavoritesWeatherComponent } from './favorites-weather/favorites-weather.component';


@NgModule({
  declarations: [
    AppComponent,
    SearchCityComponent,
    CitiesListComponent,
    FavoritesWeatherComponent,
    AboutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule           
  ],
  providers: [WeatherService],
  bootstrap: [AppComponent]
})
export class AppModule { }
