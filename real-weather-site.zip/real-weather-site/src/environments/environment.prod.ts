export const environment = {
  production: true,
  apiEndpoint: 'https://localhost:44382/api'
};
